#pragma once
#include <iostream>
#include "string.h"

using namespace std;

enum DepartmentEnum{PRODUCT, SALES, MARKETING, ART};

class Job {
    public:
        Job()
        Job(char* title, int salary, DepartmentEnum departmenmt)
        ~Job()
        
        void    setTitle(char* title);
        char*   getTitle();
        void    setSalary(int salary);
        int     getSalary();
        void    setDepartment(DepartmentEnum department);
        DepartmentEnum getDepartment();
        int     Work();
        void    Retire();

    private:
        char* m_title;
        int m_salary;
        DepartmentEnum m_department;
}
