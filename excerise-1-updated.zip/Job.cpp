#pragma once
#include <iostream>
#include "string.h"
#include "Job.h"

using namespace std;

        class Job{
            Job()
            {
                cout << "Making a new job.\n" << endl;
                setTitle(NULL);
                setSalary(-1);
                setDepartment(NULL);
            }
            Job(char* title, int salary, DepartmentEnum departmenmt)
            {
                cout << "Making a new job.\n" << endl;
                setTitle(title);
                setSalary(salary);
                setDepartment(departmenmt);
            }
            void printJob(){
                cout <<"Title: %s\n Salary: %s\n Department: %s", getTitle(), getSalary(), getDepartment() << endl;
            }
            ~Job() {}
            
            void setTitle(char* title);
            {
                cout << "%s's title updated to %s's title.\n", getTitle(), title << endl;
                strcpy(m_title, title);
            }
            char* getTitle()
            {
                return m_title;
            }
            void setSalary(int salary)
            {
                cout << "%d's salary updated to %d's salary.\n", getSalary(), salary << endl;
                m_salary = salary;
            }
            int getSalary()
            {
                return m_salary;
            }
            void setDepartment(DepartmentEnum department)
            {
                cout << "%s's department updated to %s's department.\n", getDepartment(), department << endl;
                m_department = department;
            }
            DepartmentEnum getDepartment()
            {
                return m_department;
            }
            int Work()
            {
                if (m_salary == -1)
                {
                    cout << "This person isn't working.\n" << endl;
                    return 0;
                }
                return m_salary;
            }
            void Retire()
            {                
                cout << "This person has retired.\n" << endl;
                setTitle(NULL);
                setSalary(-1);
                setDepartment(NULL);
            }
        }