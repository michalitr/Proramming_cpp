#pragma once
#include <iostream>
#include "string.h"
#include "Address.h"
#include "Job.h"

using namespace std;

class Person{
    public:
        Person()
        Person(char* name, char* phoneNumber, char* email, Address address, Job job)
        ~Person()

        void    setName(char* name);
        char*   getName(char* name);
        void    setPhoneNumber(char* phoneNumber);
        char*   getPhoneNumber();
        void    setEmail(char* email);
        char*   getEmail();
        int     getSaving();
        char*   OrderFood(Address address, int amount);
        void    printPerson();

    private:
        char* m_name;
        char* m_phoneNumber;
        char* m_email;
        int m_savings;
        Address m_address;
        Job m_job;
}