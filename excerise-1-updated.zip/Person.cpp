#pragma once
#include <iostream>
#include "string.h"
#include "Person.h"
#include "Job.h"
#include "Address.h"

using namespace std;

        class Person{
        Person()
            {
                setName(NULL);
                setPhoneNumber(NULL);
                setEmail(NULL);
                Address();
                Job();
                cout <<"A new person obj was created with\n" << endl;
                printPerson();

            }
           Person(char* name, char* phoneNumber, char* email, Address address, Job job)
            {
                setName(name);
                setPhoneNumber(phoneNumber);
                setEmail(email);
                Address(address.m_Street, address.m_City, address.m_PostalCode);
                Job(job.m_title, job.m_salary, job.m_department);
                cout <<"A new person obj was created with " << endl;
                printPerson();
                
            }
            ~Person() {}

            void setName(char* name)
            {
                cout << "%s's name updated to %s.\n", getName(name), name << endl;
                strcpy(m_name, name);
            }
            char* getName(char* name)
            {
                return m_name;
            }
            void setPhoneNumber(char* phoneNumber)
            {
                if (phoneNumber[0]!=0)
                {
                    cout << "This field must start with the digit '0'. Please re-enter a valid parameter.\n" << endl;
                    return;
                }
                strcpy(m_phoneNumber, phoneNumber);            
                cout << "%s's phone number updated to %s.\n", getName(m_name), phoneNumber << endl;           
            }
            char* getPhoneNumber()
            {
                return m_phoneNumber;
            }
            void setEmail(char* email)
            {
                cout << "%s's email updated to %s.\n", getName(m_name), email << endl;
                strcpy(m_email, email);
            }
            char* getEmail()
            {
                return m_email;
            }
            int getSaving()
            {
                return m_savings;
            }
            char* OrderFood(Address address, int amount)
            {
                if (getSaving()<=0)
                {
                    cout << "%s , you don't have enough saving to spend!\n Please wait for the next salary...\n", getName(m_name) << endl;
                    return;
                }
                cout << "%s, you ordered your food to %s, %s, %d, the amount is %d ILS.\n", getName(m_name),
                            address.getStreet(), address.getCity(), address.getPostalCode(), amount << endl;
            }
            void printPerson(){
                cout <<"Name: %s\n Phone number: %s\n Email: %s\n", getName(m_name), getPhoneNumber(), getEmail() << endl;
            }

        }