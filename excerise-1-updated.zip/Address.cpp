#pragma once
#include <iostream>
#include "string.h"
#include "Address.h"

using namespace std;

        class Address{

            Address()
            {
                setStreet(NULL);
                setCity(NULL);
                setPostalCode(-1);
                cout <<"A new person obj was created with " << endl;
                printAddress();
            }
            Address(char* street, char* City, int postalCode)
            {
                cout <<"Making a new address.\n" << endl;
                setStreet(street);
                setCity(City);
                setPostalCode(postalCode);
                printAddress();
            }
            ~Address() {}

            void setStreet(char* street) 
            {
                cout << "%s's street updated to %s's street.\n", getStreet(), street << endl;
                strcpy(m_Street, street);
            }
            char* getStreet()
            {
                return m_Street;
            }
            void etCity(char* city)
            {
                cout << "%s's city updated to %s's city.\n", getCity(), city << endl;
                strcpy(m_City, city);
            }
            char* getCity()
            {
                return m_City;
            }
            void getPostalCode(int postalCode)
            {
                cout << "%d's postal code updated to %d's postal code.\n", getPostalCode(), postalCode << endl;
                m_PostalCode = postalCode;
            }
            int getPostalCode()
            {
                return m_PostalCode;
            }
            void printAddress(){
                cout <<"Street: %s\n City: %s\n Postal Code: %s", getStreet(), getCity(), getPostalCode() << endl;
            }
        }